## Packaging Dir Template for ML Model

packaging-ml-model/
├── MANIFEST.in
├── prediction_model/
│   ├── __init__.py
│   ├── config/
│   │   ├── __init__.py
│   │   └── config.py
│   ├── datasets/
│   │   └── __init__.py
│   ├── pipeline.py
│   ├── predict.py
│   ├── processing/
│   │   ├── __init__.py
│   │   ├── data_handling.py
│   │   └── preprocessing.py
│   ├── trained_models/
│   │   └── __init__.py
│   └── training_pipeline.py
├── README.md
├── requirements.txt
├── setup.py
└── tests/
    ├── pytest.ini
    └── test_prediction.py